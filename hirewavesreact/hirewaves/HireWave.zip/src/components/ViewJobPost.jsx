
import axios from "axios";
import { useEffect, useState } from "react";
import '../styles/ViewJobPost.css'; 
import NaviBar from "./NaviBar";
import { Modal, Button, Form } from "react-bootstrap";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const ViewJobPost = () => {
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    jobTitle: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    resume: null,
    school: "",
    degree: "",
    discipline: "",
    startDate: "",
    endDate: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData((prevData) => ({
      ...prevData,
      resume: file,
    }));
  };

  useEffect(() => {
    // Fetch jobs from the backend API
    const fetchJobs = async () => {
      try {
        const response = await axios.get('http://localhost:8080/api/jobs'); // Ensure the API URL is correct
        setJobs(response.data);  
      } catch (error) {
        console.error("There was an error fetching the job listings:", error);
        toast.error("Error fetching jobs.", {
          position: "top-center",
          autoClose: 2000,
        });
      }
    };

    fetchJobs();
  }, []);  // Empty dependency to call only once

  const handleApplyClick = (job) => {
    setSelectedJob(job);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedJob(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const existingApplications =
      JSON.parse(localStorage.getItem("jobApplications")) || [];
    existingApplications.push(formData);
    localStorage.setItem(
      "jobApplications",
      JSON.stringify(existingApplications)
    );

    toast.success("Application submitted successfully!", {
      position: "top-center",
    });

    setTimeout(() => {
      navigate("/view-applicants", { state: formData });
    }, 3000);
  };

  return (
    <>
      <NaviBar />
      <div className="view-job-post-container">
        {/* Job Cards */}
        <div className="job-cards-container ">
          {jobs.length > 0 ? (
            jobs.map((job) => (
              <div key={job.id} className="job-card">
                <h3>{job.jobTitle}</h3>
                <p><strong>Company:</strong> {job.companyName}</p>
                <p><strong>Description:</strong> {job.jobDescription}</p>
                <p><strong>Location:</strong> {job.jobLocation}</p>
                <p><strong>Salary:</strong> ₹{job.jobPackage}</p>
                <p><strong>Job Type:</strong> {job.jobType}</p>
                <p><strong>Role:</strong> {job.jobRole}</p>
                <button className="apply-btn" onClick={() => handleApplyClick(job)}>
                  Apply Now
                </button>
              </div>
            ))
          ) : (
            <p id="not_available">No job postings available!</p>
          )}
        </div>

        {/* Modal for applying to jobs */}
        <Modal show={showModal} onHide={handleCloseModal}>
          <Modal.Body>
            <Form onSubmit={handleSubmit}>
              {selectedJob && (formData.jobTitle = selectedJob.jobTitle)}
              <Form.Group controlId="firstName">
                <Form.Label>First Name </Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter first name"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="lastName">
                <Form.Label>Last Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter last name"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="email">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="phone">
                <Form.Label>Phone</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter phone number"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="resume">
                <Form.Label>Upload Resume</Form.Label>
                <Form.Control
                  type="file"
                  name="resume"
                  onChange={handleFileChange}
                  required
                />
              </Form.Group>
              <Button variant="secondary" onClick={handleCloseModal}>Close</Button>
              <Button variant="primary" type="submit">Apply</Button>
            </Form>
          </Modal.Body>
        </Modal>
      </div>
    </>
  );
};

export default ViewJobPost;
