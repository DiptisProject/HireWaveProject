import AdminNavbar from "./AdminNavbar";

const AdminPage = () => {

  return (
    <>
     <AdminNavbar/>
    </>
  );
};

export default AdminPage;
